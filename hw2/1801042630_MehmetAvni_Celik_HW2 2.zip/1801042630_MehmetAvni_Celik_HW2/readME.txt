**********************************************************
	Homework 2- Part 1: G++LanguageSyntax Analyzer
	Mehmet Avni ÇELİK - 1801042630		
**********************************************************

To execute the program write to the shell the commands below:

make
./gpp_interpreter.out

To terminate the program write the code below:

(exit)
